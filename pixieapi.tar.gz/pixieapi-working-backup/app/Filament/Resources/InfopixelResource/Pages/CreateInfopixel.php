<?php

namespace App\Filament\Resources\InfopixelResource\Pages;

use App\Filament\Resources\InfopixelResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateInfopixel extends CreateRecord
{
    protected static string $resource = InfopixelResource::class;
}
